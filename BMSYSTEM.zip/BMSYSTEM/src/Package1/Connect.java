package Package1;


import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.swing.JOptionPane;

     public class Connect {

    static Connection con() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
         Connection conn=null;
    public static Connection ConnecrDb()
            
    {
       
      try
      {
          
         Class.forName("com.mysql.jdbc.Driver");
         Connection conn=(Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/mohini", "root","mohini");
      return conn;
      }
      catch(Exception ex)
      {
        JOptionPane.showMessageDialog(null, ex);
      } 

      return null;
    }
     
    }
     

